# Phase 11.2 Research UX polish
- Single workspace CTA and stepper verified.
- Config gating for external/both enforced with banner when keys missing.
- Companies filters/bulk actions/ranking and evidence links verified.
- Executive labeling, stage persistence, and pipeline redirect confirmed.