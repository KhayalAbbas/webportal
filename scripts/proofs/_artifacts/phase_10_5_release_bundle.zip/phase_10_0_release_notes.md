# Phase 10.0 Release Notes

## Summary
- Added front-door acquire+extract orchestration for discovered URL sources with deterministic proof coverage.
- Ensured fetch summary schema returns required fields for empty selection paths.
- Captured openapi before/after snapshots and endpoint excerpt for /company-research/runs/{run_id}/acquire-extract.

## Testing
- Deterministic proof: scripts/proofs/phase_10_0_acquire_extract_front_door_proof.py
- Artifacts: see scripts/proofs/_artifacts/phase_10_0_* files.
