# Phase 7.13 Release Notes

## What shipped
- Added explicit exec contact enrichment endpoints (single and bulk) in company-research router.
- Enrichment pipeline writes company research source documents before evidence creation; evidence is linked to executives and AI enrichment records.
- Idempotency: TTL/hash dedupe skips repeated requests with the same source_document_id and content hash.

## Behavior
- Single exec: POST /company-research/executives/{executive_id}/enrich_contacts triggers contact enrichment and evidence storage.
- Bulk: POST /company-research/runs/{run_id}/executives/enrich_contacts processes all execs in a run.
- Provider JSON is persisted as source_document prior to enrichment; AI enrichment records capture payload + hash provenance.

## Proof
- scripts/proofs/_artifacts/phase_7_13_proof.txt
- scripts/proofs/_artifacts/phase_7_13_proof_console.txt
