# Phase 10.2 Release Notes

## Highlights
- Added acquire_extract_async worker runner with skip-locked claims and worker_id-aware execution.
- Kept enqueue API enqueue-only; added job_type filter on claims for worker targeting.
- Concurrency proof shows single-runner execution and idempotent reuse.

## Proof Artifacts
- scripts/proofs/phase_10_2_worker_exec_concurrency_proof.py
- scripts/proofs/_artifacts/phase_10_2_proof.txt
- scripts/proofs/_artifacts/phase_10_2_proof_console.txt
- scripts/proofs/_artifacts/phase_10_2_enqueue.json
- scripts/proofs/_artifacts/phase_10_2_status.json
- scripts/proofs/_artifacts/phase_10_2_worker1_log.txt
- scripts/proofs/_artifacts/phase_10_2_worker2_log.txt
- scripts/proofs/_artifacts/phase_10_2_db_excerpt.txt
- scripts/proofs/_artifacts/phase_10_2_openapi_after.json
- scripts/proofs/_artifacts/phase_10_2_openapi_after_excerpt.txt

## Notes
- Worker uses existing repo locking (FOR UPDATE SKIP LOCKED) and mark_job_running.
- execute_acquire_extract_job now accepts worker_id to attribute ownership.
- claim_next_job accepts optional job_type to isolate worker polling.
