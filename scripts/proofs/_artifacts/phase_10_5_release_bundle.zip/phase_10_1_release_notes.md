# Phase 10.1 Release Notes

## Summary
- Added async acquire+extract enqueue and status endpoints with params hashing for idempotent reuse and force overrides.
- Persisted job params/progress/error metadata on CompanyResearchJob and aligned repository/service handling for async execution.
- Wired async execution to existing run_acquire_extract pipeline with event logging and progress capture.
- Captured OpenAPI snapshot and excerpt for the new async job endpoints.

## Testing
- Deterministic proof: scripts/proofs/phase_10_1_acquire_extract_async_job_proof.py
- Artifacts: see scripts/proofs/_artifacts/phase_10_1_* files.
