# Phase 7.12 release notes (snippet)

## Endpoints added/changed
- POST /company-research/executives/{executive_id}/pipeline — create ATS pipeline records from an accepted executive prospect (auth: HTTPBearer, optional x-tenant-id header). Request body: ExecutivePipelineCreate. Response: ExecutivePipelineCreateResponse.
- PATCH /company-research/executives/{executive_id}/review-status — update executive review gate status with audit logging (auth: HTTPBearer, optional x-tenant-id header). Request body: ExecutiveReviewUpdate. Response: ExecutiveProspectRead.
- PATCH /company-research/prospects/{prospect_id}/review-status — update company prospect review gate status with audit logging (auth: HTTPBearer, optional x-tenant-id header). Request body: CompanyProspectReviewUpdate. Response: CompanyProspectRead.
- POST /ui/company-research/prospects/{prospect_id}/review-status — UI form handler for review gate updates. Request body: form Body_update_prospect_review_status_ui_*. Response: JSON envelope.

## Database changes
- Migration 1f9b5c17f8da (head) adds executive_prospects.review_status (String(50), NOT NULL, default 'new').
- New index ix_executive_prospects_review_status on (tenant_id, company_research_run_id, review_status).

## Behavioral rules
- Pipeline promotion is allowed only when the executive review_status is accepted; creates candidate + assignment + research_event with provenance/external metadata and returns ids.
- Every review decision change (new/hold/rejected/accepted) writes an EXECUTIVE_REVIEW_STATUS audit log entry; pipeline promotion writes EXECUTIVE_PIPELINE_CREATE with run/executive/prospect/candidate identifiers and evidence provenance.
