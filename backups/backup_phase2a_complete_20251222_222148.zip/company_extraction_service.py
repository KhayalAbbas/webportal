"""
Company Extraction Service - Phase 2A processing pipeline.

Handles source fetching, company name extraction, deduplication,
and prospect creation from raw sources.
"""

import hashlib
import re
from typing import List, Tuple, Optional, Set
from uuid import UUID
from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.company_research_repo import CompanyResearchRepository
from app.models.company_research import ResearchSourceDocument, CompanyProspect
from app.schemas.company_research import (
    ResearchEventCreate,
    CompanyProspectCreate,
    CompanyProspectEvidenceCreate,
    SourceDocumentUpdate,
)


class CompanyExtractionService:
    """Service for extracting companies from source documents."""
    
    def __init__(self, db: AsyncSession):
        self.db = db
        self.repo = CompanyResearchRepository(db)
    
    async def process_sources(
        self,
        tenant_id: str,
        run_id: UUID,
    ) -> dict:
        """
        Process all pending sources for a research run.
        
        Returns summary of processing results.
        """
        # Load processable sources
        sources = await self.repo.get_processable_sources(tenant_id, run_id)
        
        if not sources:
            return {
                "processed": 0,
                "companies_found": 0,
                "companies_new": 0,
                "companies_existing": 0,
            }
        
        # Log fetch event
        await self.repo.create_research_event(
            tenant_id=tenant_id,
            data=ResearchEventCreate(
                company_research_run_id=run_id,
                event_type="fetch",
                status="ok",
                input_json={"source_count": len(sources)},
            ),
        )
        
        total_companies = 0
        total_new = 0
        total_existing = 0
        
        # Process each source
        for source in sources:
            try:
                # Extract text content if needed
                if source.status == "new":
                    await self._fetch_content(tenant_id, source)
                
                # Extract company names
                companies = self._extract_company_names(source.content_text or "")
                
                # Log extraction event
                await self.repo.create_research_event(
                    tenant_id=tenant_id,
                    data=ResearchEventCreate(
                        company_research_run_id=run_id,
                        event_type="extract",
                        status="ok",
                        input_json={"source_id": str(source.id)},
                        output_json={
                            "companies_found": len(companies),
                            "companies": [{"name": c[0], "snippet": c[1][:100]} for c in companies[:10]],
                        },
                    ),
                )
                
                # Deduplicate and create prospects
                new_count, existing_count = await self._deduplicate_and_create_prospects(
                    tenant_id=tenant_id,
                    run_id=run_id,
                    source=source,
                    companies=companies,
                )
                
                total_companies += len(companies)
                total_new += new_count
                total_existing += existing_count
                
                # Mark source as processed
                await self.repo.update_source_document(
                    tenant_id=tenant_id,
                    source_id=source.id,
                    data=SourceDocumentUpdate(status="processed"),
                )
                
            except Exception as e:
                # Mark source as failed
                await self.repo.update_source_document(
                    tenant_id=tenant_id,
                    source_id=source.id,
                    data=SourceDocumentUpdate(
                        status="failed",
                        error_message=str(e),
                    ),
                )
                
                # Log error event
                await self.repo.create_research_event(
                    tenant_id=tenant_id,
                    data=ResearchEventCreate(
                        company_research_run_id=run_id,
                        event_type="extract",
                        status="failed",
                        input_json={"source_id": str(source.id)},
                        error_message=str(e),
                    ),
                )
        
        return {
            "processed": len(sources),
            "companies_found": total_companies,
            "companies_new": total_new,
            "companies_existing": total_existing,
        }
    
    async def _fetch_content(
        self,
        tenant_id: str,
        source: ResearchSourceDocument,
    ) -> None:
        """Fetch and extract content from source."""
        
        if source.source_type == "url":
            # For Phase 2A, just use URL as content if no content_text
            if not source.content_text and source.url:
                # Simple placeholder - in real implementation, would fetch HTML
                content = f"Company information from {source.url}"
                source.content_text = content
                source.content_hash = hashlib.sha256(content.encode()).hexdigest()
                source.status = "fetched"
                source.fetched_at = datetime.utcnow()
        
        elif source.source_type == "pdf":
            # For Phase 2A, placeholder - would extract PDF text
            if not source.content_text:
                source.content_text = "PDF content placeholder"
                source.content_hash = hashlib.sha256(source.content_text.encode()).hexdigest()
                source.status = "fetched"
                source.fetched_at = datetime.utcnow()
        
        elif source.source_type == "text":
            # Text is already provided
            if source.content_text:
                source.content_hash = hashlib.sha256(source.content_text.encode()).hexdigest()
                source.status = "fetched"
                source.fetched_at = datetime.utcnow()
        
        await self.db.commit()
        await self.db.refresh(source)
    
    def _extract_company_names(self, text: str) -> List[Tuple[str, str]]:
        """
        Extract company names from text using rule-based heuristics.
        
        Returns list of (company_name, snippet) tuples.
        """
        if not text:
            return []
        
        companies = []
        seen_normalized = set()
        
        # Split into lines
        lines = text.split('\n')
        
        for i, line in enumerate(lines):
            line = line.strip()
            if not line:
                continue
            
            # Pattern 1: Lines with company suffixes
            suffixes = r'\b(Ltd|LLC|PLC|SAOG|SA|GmbH|AG|Inc|Corp|Corporation|Limited|Group|Holdings)\b'
            if re.search(suffixes, line, re.IGNORECASE):
                # Extract company name (everything before suffix + suffix)
                match = re.search(r'([A-Z][A-Za-z\s&.-]+?' + suffixes + r')', line, re.IGNORECASE)
                if match:
                    company_name = match.group(1).strip()
                    normalized = self._normalize_company_name(company_name)
                    
                    if normalized not in seen_normalized and len(normalized) >= 3:
                        seen_normalized.add(normalized)
                        # Get snippet (current line + next line if exists)
                        snippet = line
                        if i + 1 < len(lines):
                            snippet += " " + lines[i + 1].strip()
                        companies.append((company_name, snippet[:500]))
            
            # Pattern 2: Title Case sequences (potential company names)
            # Look for 2-5 capitalized words in sequence
            title_pattern = r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,4})\b'
            matches = re.finditer(title_pattern, line)
            for match in matches:
                company_name = match.group(1).strip()
                normalized = self._normalize_company_name(company_name)
                
                # Filter out common non-company phrases
                if self._is_likely_company_name(company_name) and normalized not in seen_normalized:
                    seen_normalized.add(normalized)
                    snippet = line
                    if i + 1 < len(lines):
                        snippet += " " + lines[i + 1].strip()
                    companies.append((company_name, snippet[:500]))
        
        return companies
    
    def _normalize_company_name(self, name: str) -> str:
        """Normalize company name for deduplication."""
        # Convert to lowercase
        normalized = name.lower()
        
        # Remove common suffixes
        suffixes = [
            ' ltd', ' llc', ' plc', ' saog', ' sa', ' gmbh', ' ag',
            ' inc', ' corp', ' corporation', ' limited', ' group', ' holdings',
            '.', ',',
        ]
        for suffix in suffixes:
            if normalized.endswith(suffix):
                normalized = normalized[:-len(suffix)]
        
        # Remove extra whitespace
        normalized = ' '.join(normalized.split())
        
        return normalized.strip()
    
    def _is_likely_company_name(self, name: str) -> bool:
        """Filter out common non-company phrases."""
        # Exclude common words that appear in Title Case but aren't companies
        excluded = {
            'The Company', 'Our Company', 'This Company', 'Your Company',
            'New York', 'Los Angeles', 'San Francisco', 'United States',
            'United Kingdom', 'European Union', 'North America',
            'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday',
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December',
        }
        
        return name not in excluded and len(name) >= 3
    
    async def _deduplicate_and_create_prospects(
        self,
        tenant_id: str,
        run_id: UUID,
        source: ResearchSourceDocument,
        companies: List[Tuple[str, str]],
    ) -> Tuple[int, int]:
        """
        Deduplicate companies against existing prospects and create new ones.
        
        Returns (new_count, existing_count).
        """
        # Get existing prospects for this run
        existing_prospects = await self.repo.list_company_prospects_for_run(
            tenant_id=tenant_id,
            run_id=run_id,
        )
        
        existing_normalized = {
            self._normalize_company_name(p.name_normalized): p
            for p in existing_prospects
        }
        
        new_count = 0
        existing_count = 0
        
        for company_name, snippet in companies:
            normalized = self._normalize_company_name(company_name)
            
            if normalized in existing_normalized:
                # Company already exists - add evidence only
                prospect = existing_normalized[normalized]
                await self.repo.create_prospect_evidence(
                    tenant_id=tenant_id,
                    data=CompanyProspectEvidenceCreate(
                        company_prospect_id=prospect.id,
                        source_type="document",
                        source_name=source.title or source.source_type,
                        source_url=source.url,
                        evidence_snippet=snippet,
                        evidence_weight=0.5,
                    ),
                )
                existing_count += 1
            
            else:
                # New company - create prospect
                # Get role_mandate_id from the research run
                run = await self.repo.get_company_research_run(tenant_id, run_id)
                if not run:
                    continue
                
                prospect = await self.repo.create_company_prospect(
                    tenant_id=tenant_id,
                    data=CompanyProspectCreate(
                        company_research_run_id=run_id,
                        role_mandate_id=run.role_mandate_id,
                        name_raw=company_name,
                        name_normalized=normalized,
                        sector=run.sector,  # Inherit from run
                        relevance_score=0.5,  # Default score
                        evidence_score=0.5,
                        is_pinned=False,
                        status="new",
                    ),
                )
                
                # Create evidence
                await self.repo.create_prospect_evidence(
                    tenant_id=tenant_id,
                    data=CompanyProspectEvidenceCreate(
                        company_prospect_id=prospect.id,
                        source_type="document",
                        source_name=source.title or source.source_type,
                        source_url=source.url,
                        evidence_snippet=snippet,
                        evidence_weight=0.5,
                    ),
                )
                
                existing_normalized[normalized] = prospect
                new_count += 1
        
        # Log dedupe event
        await self.repo.create_research_event(
            tenant_id=tenant_id,
            data=ResearchEventCreate(
                company_research_run_id=run_id,
                event_type="dedupe",
                status="ok",
                input_json={"source_id": str(source.id)},
                output_json={
                    "new_companies": new_count,
                    "existing_companies": existing_count,
                },
            ),
        )
        
        return new_count, existing_count
