"""
Tests package for ATS application.
"""
