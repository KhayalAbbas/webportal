"""
UI routes initialization.
"""
