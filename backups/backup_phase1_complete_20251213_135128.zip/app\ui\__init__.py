"""
UI module initialization.
"""
